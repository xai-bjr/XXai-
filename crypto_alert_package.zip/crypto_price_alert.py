#!/usr/bin/env python3
import argparse
import json
import time
import requests
import smtplib
from email.mime.text import MIMEText
from datetime import datetime
import csv

def load_config(path):
    with open(path, "r") as f:
        return json.load(f)

def fetch_price(coin_ids):
    url = "https://api.coingecko.com/api/v3/simple/price"
    resp = requests.get(url, params={"ids": ",".join(coin_ids), "vs_currencies": "usd"})
    resp.raise_for_status()
    return resp.json()

def log_price(logfile, prices):
    with open(logfile, "a", newline="") as f:
        writer = csv.writer(f)
        ts = datetime.utcnow().isoformat()
        for coin, data in prices.items():
            writer.writerow([ts, coin, data["usd"]])

def send_email(smtp_config, to_email, subject, body):
    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = smtp_config["user"]
    msg["To"] = to_email

    with smtplib.SMTP(smtp_config["server"], smtp_config["port"]) as server:
        server.starttls()
        server.login(smtp_config["user"], smtp_config["password"])
        server.send_message(msg)

def check_thresholds(prices, thresholds):
    alerts = []
    for coin, data in prices.items():
        price = data["usd"]
        if coin in thresholds:
            for cond, val in thresholds[coin].items():
                if cond == "below" and price < val:
                    alerts.append(f"{coin} dropped below {val} (now {price})")
                elif cond == "above" and price > val:
                    alerts.append(f"{coin} rose above {val} (now {price})")
    return alerts

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", help="Path to config JSON")
    parser.add_argument("--coins", help="Comma-separated coin IDs")
    parser.add_argument("--interval", type=int, help="Polling interval (seconds)")
    parser.add_argument("--thresholds", help="Comma-separated like coin:below:40000,coin:above:2000")
    parser.add_argument("--notify-email", help="Email to notify")
    parser.add_argument("--smtp-server")
    parser.add_argument("--smtp-port", type=int)
    parser.add_argument("--smtp-user")
    parser.add_argument("--smtp-pass")
    parser.add_argument("--logfile", default="prices.csv")
    args = parser.parse_args()

    config = {}
    if args.config:
        config = load_config(args.config)

    coins = (args.coins.split(",") if args.coins else config.get("coins", []))
    interval = args.interval or config.get("interval", 60)
    thresholds = config.get("thresholds", {})
    if args.thresholds:
        thresholds = {}
        for t in args.thresholds.split(","):
            coin, cond, val = t.split(":")
            thresholds.setdefault(coin, {})[cond] = float(val)

    notify_email = args.notify_email or config.get("notify_email")
    smtp = config.get("smtp", {})
    if args.smtp_server:
        smtp.update({
            "server": args.smtp_server,
            "port": args.smtp_port,
            "user": args.smtp_user,
            "password": args.smtp_pass
        })

    while True:
        try:
            prices = fetch_price(coins)
            log_price(args.logfile, prices)
            alerts = check_thresholds(prices, thresholds)
            if alerts and notify_email:
                send_email(smtp, notify_email, "Crypto Alert", "\n".join(alerts))
                print("Alert sent:", alerts)
            else:
                print(datetime.utcnow().isoformat(), prices)
        except Exception as e:
            print("Error:", e)
        time.sleep(interval)

if __name__ == "__main__":
    main()
